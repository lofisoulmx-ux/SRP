import React from "react";

function App() {
  return (
    <main>
      <section className="hero">
        <div className="hero__content">
          <span className="eyebrow">SAN REY PRODUCE</span>
          <h1>Freshness<br /><em>in motion.</em></h1>
          <p>From field to market.</p>
        </div>
      </section>

      <section className="placeholder">
        <span>02</span>
        <h2>Products</h2>
      </section>

      <section className="placeholder">
        <span>03</span>
        <h2>Infrastructure</h2>
      </section>

      <section className="placeholder">
        <span>04</span>
        <h2>Our Route</h2>
      </section>

      <section className="placeholder">
        <span>05</span>
        <h2>Global Presence</h2>
      </section>
    </main>
  );
}

export default App;
